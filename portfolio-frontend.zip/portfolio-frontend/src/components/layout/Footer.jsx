import { Link } from 'react-router-dom';

const YEAR = new Date().getFullYear();

const NAV = [
  { path: '/',        label: 'Acasă'   },
  { path: '/blog',    label: 'Blog'    },
  { path: '/about',   label: 'Despre'  },
  { path: '/contact', label: 'Contact' },
];

export default function Footer() {
  return (
    <footer className="bg-gray-50 dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800">
      <div className="max-w-6xl mx-auto px-6 py-12">

        {/* Grid 3 coloane */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 mb-10">

          {/* Col 1: Logo + tagline */}
          <div>
            <Link to="/" className="inline-flex items-center gap-2.5 font-heading font-bold text-xl
              text-gray-900 dark:text-white mb-3">
              <span className="w-8 h-8 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-lg
                flex items-center justify-center text-white text-sm font-black">P</span>
              Portfolio
            </Link>
            <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">
              Site de prezentare personal — proiecte, tutoriale și reflecții despre web development.
            </p>
            {/* Logo text accent font */}
            <p className="font-accent italic text-gray-400 dark:text-gray-500 text-sm mt-2">
              Cod, design & idei.
            </p>
          </div>

          {/* Col 2: Navigare */}
          <div>
            <h3 className="font-heading font-bold text-gray-900 dark:text-white mb-4 text-sm uppercase tracking-wider">
              Navigare
            </h3>
            <ul className="space-y-2">
              {NAV.map(({ path, label }) => (
                <li key={path}>
                  <Link
                    to={path}
                    className="text-sm text-gray-500 dark:text-gray-400
                      hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Social */}
          <div>
            <h3 className="font-heading font-bold text-gray-900 dark:text-white mb-4 text-sm uppercase tracking-wider">
              Social
            </h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://github.com/username"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400
                    hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.373 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/>
                  </svg>
                  GitHub
                </a>
              </li>
              <li>
                <a
                  href="https://linkedin.com/in/username"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400
                    hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0H5C2.239 0 0 2.239 0 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5V5c0-2.761-2.238-5-5-5zM8 19H5V8h3v11zM6.5 6.732c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zM20 19h-3v-5.604c0-3.368-4-3.113-4 0V19h-3V8h3v1.765c1.396-2.586 7-2.777 7 2.476V19z"/>
                  </svg>
                  LinkedIn
                </a>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400
                    hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round"
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                  </svg>
                  Contact
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bara de jos: copyright */}
        <div className="pt-6 border-t border-gray-100 dark:border-slate-800
          flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-400 dark:text-gray-500">
            © {YEAR} Portfolio Personal. Toate drepturile rezervate.
          </p>
          <p className="text-xs text-gray-400 dark:text-gray-500">
            Realizat cu React, Tailwind CSS &amp; Strapi
          </p>
        </div>
      </div>
    </footer>
  );
}
